import brain_games.scripts.brain_games as game
from brain_games.games_logic import check_even


def main():
    game.main(check_even)


if __name__ == '__main__':
    main()
