# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts', 'brain_games.tools']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.games.brain_calc:main',
                     'brain-even = brain_games.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.games.brain_gcd:main',
                     'brain-prime = brain_games.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Игры разума',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Alexander-Ageev/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Alexander-Ageev/python-project-49/actions)\n\nПроект "Игры разума".\nСодержит в себе следующие игры:\n1. brain_even - игра на проверку четности. Если число четное, нужно ответить yesб иначе - no\n2. brain_calc - игра позволяет проверить навыки вычисления\n(сумма, разность и произведение) двух чисел. \n3. brain_gcd - игра, в которой нужно найти наибольший общий делитель для двух чисел.\n4. brain_progression - игра, в которой необходимо определить\nпропущенный элемент арифметической прогрессии.\n5. brain_prime - игра, в которой нужно определить, является ли\nпредложенное число простым. Если является - ответить yes,\nв противном случае - no.\n\nВсе игры проходят три раунда. Если в одном из раундов игрок ошибся - он проиграл, а игра заканчивается.\n\nУстановка:\npip install --user git+github.com:Alexander-Ageev/python-project-49.git\n\nДля запуска игры нужно набрать соответсвующую команду (brain-even и т.п.)\n\n<a href="https://codeclimate.com/github/Alexander-Ageev/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b12e7eba7ccaf1416b27/maintainability" /></a>\n\n<a href="https://asciinema.org/a/554903?startAt=18" target="_blank"><img src="https://asciinema.org/a/554903.svg"/></a>\n\n<a href="https://asciinema.org/a/557337" target="_blank"><img src="https://asciinema.org/a/557337.svg" /></a>\n\n<a href="https://asciinema.org/a/557349" target="_blank"><img src="https://asciinema.org/a/557349.svg" /></a>\n\n<a href="https://asciinema.org/a/557574" target="_blank"><img src="https://asciinema.org/a/557574.svg" /></a>\n\n<a href="https://asciinema.org/a/557576" target="_blank"><img src="https://asciinema.org/a/557576.svg" /></a>',
    'author': 'Alexander',
    'author_email': 'alexandrageev87@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'github.com:Alexander-Ageev/python-project-49.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
