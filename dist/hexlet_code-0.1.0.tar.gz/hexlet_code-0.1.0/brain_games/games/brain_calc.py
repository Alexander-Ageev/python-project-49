import brain_games.scripts.brain_games as games
from brain_games.games_logic import calc


def main():
    games.main(calc)


if __name__ == '__main__':
    main()
