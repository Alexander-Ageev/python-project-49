### Hexlet tests and linter status:
[![Actions Status](https://github.com/Alexander-Ageev/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Alexander-Ageev/python-project-49/actions)

<a href="https://codeclimate.com/github/Alexander-Ageev/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b12e7eba7ccaf1416b27/maintainability" /></a>